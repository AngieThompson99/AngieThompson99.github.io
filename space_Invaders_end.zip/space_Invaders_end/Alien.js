class Alien {
    constructor(x, y) { //pass parameter
        this.pos = createVector(x, y); //stores positions of x and y using vector
        this.velocity = alienVelocity; //the rate at which the alien moves
    }

    render() {
        
        push()
        translate (this.pos.x, this.pos.y);  // using translate, 
        //we move the canvas so that the alien thinks its at 0,0 but it is really in the middle of the axis
        //ellipse(0,0,alienWidth,alienHeight)
        image(alienImg,0,0,alienWidth, alienHeight);
        //fill(255,0,0);
        //ellipse(0, 0, alienWidth, alienHeight);
        pop()
    }
    move() {
        this.pos.x += this.velocity;
    }

    shift(){
        this.pos.y += shiftDown; // shifts y down
        this.velocity *= -1; //changed x direction (when it shifts down)
    }

}